package jp.co.aico.controller.add;

import org.springframework.stereotype.Controller;

@Controller
public class AddController {

}
