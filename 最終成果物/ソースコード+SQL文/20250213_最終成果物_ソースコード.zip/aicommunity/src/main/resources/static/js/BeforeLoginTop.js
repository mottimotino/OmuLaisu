import { gsap } from './gsap_3.6.1/esm/gsap-core.js';
import { CSSPlugin } from './gsap_3.6.1/esm/CSSPlugin.js';

document.querySelectorAll(".js-g06").forEach((item, i) => {
  gsap.from(item, {
    opacity: 0,
    rotationX: 360,
    ease: "power1",
    duration: 0.5,
    delay: i * 0.05
  });
});