package jp.co.aico.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.co.aico.entity.QAEntity;

public interface QARepository extends JpaRepository<QAEntity,Integer >{

}
