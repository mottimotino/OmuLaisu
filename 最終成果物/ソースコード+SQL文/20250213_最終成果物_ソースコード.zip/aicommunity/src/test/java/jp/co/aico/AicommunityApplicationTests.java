package jp.co.aico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AicommunityApplicationTests {

	@Test
	void contextLoads() {
	}

}
