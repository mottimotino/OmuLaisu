package jp.co.aico.repository;

public interface HelpRepository {

}
