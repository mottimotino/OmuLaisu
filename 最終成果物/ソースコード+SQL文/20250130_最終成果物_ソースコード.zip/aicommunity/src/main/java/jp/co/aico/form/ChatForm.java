package jp.co.aico.form;

public class ChatForm {
	
	private Integer sendUser;
	
	private Integer receUser;
	
	private String message;

	public Integer getSendUser() {
		return sendUser;
	}

	public void setSendUser(Integer sendUser) {
		this.sendUser = sendUser;
	}

	public Integer getReceUser() {
		return receUser;
	}

	public void setReceUser(Integer receUser) {
		this.receUser = receUser;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	
	
	
	

}
