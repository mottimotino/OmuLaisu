package jp.co.aico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AicommunityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AicommunityApplication.class, args);
	}

}