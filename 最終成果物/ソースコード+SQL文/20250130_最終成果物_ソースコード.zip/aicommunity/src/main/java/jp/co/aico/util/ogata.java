package jp.co.aico.util;

public class ogata {

}
