package jp.co.aico.validator;

public class ogata {

}
