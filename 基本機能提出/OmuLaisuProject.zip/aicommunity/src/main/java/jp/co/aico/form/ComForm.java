package jp.co.aico.form;

public class ComForm {

private Integer dateId;
private String day;
private String weekday;
private Integer timesId;
private  Integer usersId;
public Integer getDateId() {
	return dateId;
}
public void setDateId(Integer dateId) {
	this.dateId = dateId;
}
public String getDay() {
	return day;
}
public void setDay(String day) {
	this.day = day;
}
public String getWeekday() {
	return weekday;
}
public void setWeekday(String weekday) {
	this.weekday = weekday;
}
public Integer getTimesId() {
	return timesId;
}
public void setTimesId(Integer timesId) {
	this.timesId = timesId;
}
public Integer getUsersId() {
	return usersId;
}
public void setUsersId(Integer usersId) {
	this.usersId = usersId;
}

}
