package jp.co.aico.form;

public class LoginForm {

}
